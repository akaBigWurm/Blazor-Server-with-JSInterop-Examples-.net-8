## JavaScript Interoperability (Interop) in Text Processor Component

The `Text Processor` component utilizes Blazor's JavaScript interop to enhance user interactions and manage focus seamlessly. Here's a concise overview of how interop is implemented in the code:

1. **Setting Up Event Handlers via JavaScript**:
    - **`setupKeydownHandler` Function**: This JavaScript function attaches a `keydown` event listener to the textarea element. When the Enter key is pressed, it prevents the default newline insertion and invokes the `.NET` method `ProcessText` asynchronously using the provided `DotNetObjectReference`.
    - **`setFocus` Function**: This function programmatically sets focus to the specified DOM element, ensuring that the textarea is active for user input when needed.

2. **Creating a .NET Object Reference**:
    - In the `OnAfterRenderAsync` lifecycle method, a `DotNetObjectReference` is created for the component instance (`this`). This reference (`dotNetHelperRef`) allows JavaScript to call the `.NET` method `ProcessText`.

3. **Invoking JavaScript from .NET**:
    - **Initializing Handlers**: Upon first render, the component invokes `setupKeydownHandler` to attach the keydown event listener and `setFocus` to focus the textarea.
    - **Focus Management**: After processing text or clearing input, the component calls `setFocus` to ensure the textarea remains focused for continued user input.

4. **Exposing .NET Methods to JavaScript**:
    - The `ProcessText` method is decorated with `[JSInvokable]`, making it callable from JavaScript. This method handles text processing logic when triggered by JavaScript events.

5. **Clipboard Operations via Interop**:
    - **Pasting Text**: The `PasteFromClipboard` method uses `JSRuntime.InvokeAsync<string>("navigator.clipboard.readText")` to read text from the clipboard.
    - **Copying Text**: The `CopyProcessedText` method writes processed text to the clipboard using `JSRuntime.InvokeVoidAsync("navigator.clipboard.writeText", ProcessedText)`.

6. **Resource Management**:
    - The component implements `IDisposable` to dispose of the `DotNetObjectReference` (`dotNetHelperRef`) when the component is destroyed, preventing potential memory leaks.

### Workflow Summary

1. **Initialization**:
    - On first render, JavaScript functions are set up to handle keydown events and focus management.
  
2. **User Interaction**:
    - When the user presses Enter or pastes text, JavaScript invokes the `.NET` `ProcessText` method to handle the input.
  
3. **Processing and Feedback**:
    - The `.NET` method processes the text, updates the UI, and uses JavaScript to maintain focus or handle clipboard operations as needed.

This interop strategy enables efficient communication between Blazor's server-side logic and client-side JavaScript, resulting in a responsive and user-friendly text processing experience.



---------------------------------------------------------------------------------------------------------------


## JavaScript Flow in Text Processor Application

The Text Processor application leverages JavaScript to handle user interactions, manage UI updates, and perform asynchronous operations seamlessly. Below is a detailed overview of the JavaScript flow within the application:

### 1. **Initialization on Page Load**

- **Event Listener Setup**:
  - **`DOMContentLoaded`**: When the DOM is fully loaded, the `DOMContentLoaded` event triggers the initialization functions:
    - **`updateCharacterCount()`**: Initializes the character counter based on the current textarea content.
    - **Auto-Focus**: Sets focus to the textarea (`inputText`) to enhance user experience by allowing immediate typing.

```javascript
document.addEventListener("DOMContentLoaded", function () {
    updateCharacterCount();
    const inputText = document.getElementById("inputText");
    if (inputText) {
        inputText.focus();
    }
});
```

### 2. **Character Counting**

- **`updateCharacterCount()`**:
  - **Purpose**: Updates the live character count displayed below the textarea.
  - **Trigger**: Invoked on `input` events and after paste operations to reflect the current number of characters entered by the user.

```javascript
function updateCharacterCount() {
    const inputText = document.getElementById("inputText").value;
    const charCount = inputText.length;
    document.getElementById("charCount").innerText = `${charCount} / 300 characters`;
}
```

### 3. **Handling User Input Events**

- **Keydown Event**:
  - **`handleKeyDown(event)`**:
    - **Purpose**: Detects when the Enter key is pressed without the Shift key to trigger text processing.
    - **Behavior**: Prevents the default action (inserting a newline) and calls `processText()`.

```javascript
function handleKeyDown(event) {
    if (event.key === "Enter" && !event.shiftKey) {
        event.preventDefault();
        processText();
    }
}
```

- **Paste Event**:
  - **Inline Event Listener**:
    - **Purpose**: Handles paste actions into the textarea.
    - **Behavior**: After a paste occurs, a slight delay ensures the pasted content is captured, then updates the character count and triggers text processing.

```javascript
document.getElementById("inputText").addEventListener("paste", function () {
    setTimeout(() => {
        updateCharacterCount();
        processText(); // Trigger text processing after pasting
    }, 100);
});
```

### 4. **Button Actions**

- **Clear Button (`clearInputText()`)**:
  - **Purpose**: Clears the textarea and any displayed processed text or error messages.
  - **Behavior**: Resets the input field, hides the processed text section, and updates the character count.

```javascript
function clearInputText() {
    document.getElementById("inputText").value = "";
    document.getElementById("processedText").innerHTML = "";
    document.getElementById("processedTextSection").style.display = "none";

    const errorMessageElement = document.getElementById("errorMessage");
    errorMessageElement.classList.add("d-none");
    errorMessageElement.innerText = "";
    updateCharacterCount();
}
```

- **Paste Button (`pasteFromClipboard()`)**:
  - **Purpose**: Pastes text from the user's clipboard into the textarea.
  - **Behavior**: Reads text from the clipboard, truncates it to 300 characters if necessary, updates the textarea, character count, and triggers text processing.

```javascript
async function pasteFromClipboard() {
    try {
        const text = await navigator.clipboard.readText();
        const trimmedText = text.length > 300 ? text.substring(0, 300) : text;
        document.getElementById("inputText").value = trimmedText;
        updateCharacterCount();
        processText(); // Trigger text processing after pasting
    } catch (err) {
        displayError("Failed to paste: " + err.message);
    }
}
```

- **Process Text Button (`processText()`)**:
  - **Purpose**: Initiates the text processing workflow.
  - **Behavior**:
    1. **Validation**: Ensures the textarea is not empty.
    2. **UI Updates**: Shows the loading spinner and hides previous results or error messages.
    3. **Asynchronous Processing**: Calls `mockProcessText()` to simulate text processing.
    4. **Displaying Results**: Upon successful processing, displays the processed text with a copy button.
    5. **Error Handling**: Shows error messages if processing fails.

```javascript
async function processText() {
    const inputText = document.getElementById("inputText").value.trim();
    const errorMessageElement = document.getElementById("errorMessage");
    const loadingSpinner = document.getElementById("loadingSpinner");
    const processedTextSection = document.getElementById("processedTextSection");
    const processedTextElement = document.getElementById("processedText");

    // Reset messages and sections
    errorMessageElement.classList.add("d-none");
    errorMessageElement.innerText = "";
    loadingSpinner.classList.remove("d-none");
    processedTextSection.style.display = "none";
    processedTextElement.innerHTML = "";

    // Validate input
    if (!inputText) {
        displayError("Please enter some text.");
        loadingSpinner.classList.add("d-none");
        return;
    }

    try {
        // Call the mock function instead of a real API
        const result = await mockProcessText(inputText);
        loadingSpinner.classList.add("d-none");

        // Display the "Processed Text"
        const textRow = document.createElement("tr");

        const textCell = document.createElement("td");
        textCell.className = "align-middle";
        textCell.innerText = result.processed_text || "No processed text available.";
        textRow.appendChild(textCell);

        const buttonCell = document.createElement("td");
        buttonCell.className = "align-middle";
        const copyButton = document.createElement("button");
        copyButton.innerText = "Copy";
        copyButton.className = "btn btn-primary btn-sm";
        copyButton.onclick = () => {
            navigator.clipboard
                .writeText(result.processed_text)
                .then(() => alert("Processed text copied to clipboard!"))
                .catch((err) => alert("Failed to copy text: " + err));
        };
        buttonCell.appendChild(copyButton);
        textRow.appendChild(buttonCell);

        processedTextElement.appendChild(textRow);
        processedTextSection.style.display = "block";
    } catch (error) {
        loadingSpinner.classList.add("d-none");
        displayError("An error occurred while processing your request.");
        console.error(error);
    }
}
```

### 5. **Mock Text Processing**

- **`mockProcessText(inputText)`**:
  - **Purpose**: Simulates an asynchronous API call to process the input text.
  - **Behavior**: Returns a promise that resolves after a 1-second delay with a mock processed text.

```javascript
async function mockProcessText(inputText) {
    // Simulate delay
    return new Promise((resolve) => {
        setTimeout(() => {
            // Return an object with "processed_text" key
            // This could be a call to an API
            resolve({ processed_text: "Mock processed text: " + inputText });
        }, 1000); // 1-second delay to simulate processing time
    });
}
```

### 6. **Error Handling**

- **`displayError(message)`**:
  - **Purpose**: Displays error messages to the user using a Bootstrap alert.
  - **Behavior**: Sets the error message text and makes the alert visible.

```javascript
function displayError(message) {
    const errorMessageElement = document.getElementById("errorMessage");
    errorMessageElement.innerText = message;
    errorMessageElement.classList.remove("d-none");
}
```

### 7. **Copying Processed Text**

- **Copy Button within Processed Text Section**:
  - **Purpose**: Allows users to copy the processed text to their clipboard.
  - **Behavior**: Utilizes the Clipboard API to write text and provides feedback via alerts.

```javascript
copyButton.onclick = () => {
    navigator.clipboard
        .writeText(result.processed_text)
        .then(() => alert("Processed text copied to clipboard!"))
        .catch((err) => alert("Failed to copy text: " + err));
};
```

### 8. **UI Components Interaction**

- **Loading Spinner**:
  - **Purpose**: Indicates to the user that text processing is in progress.
  - **Behavior**: Displayed when processing starts and hidden upon completion or error.

- **Processed Text Section**:
  - **Purpose**: Shows the result of the text processing.
  - **Behavior**: Populated with the processed text and a copy button upon successful processing.

- **Error Message Alert**:
  - **Purpose**: Alerts the user of any issues during text processing or clipboard operations.
  - **Behavior**: Dynamically shows or hides based on the presence of errors.

### 9. **Summary of Workflow**

1. **User Input**:
   - The user types text into the textarea. The character count updates in real-time.
   - Pressing Enter (without Shift) or clicking the "Process Text" button triggers the `processText()` function.
   - Pasting text via keyboard shortcuts or the "Paste" button also triggers text processing.

2. **Processing**:
   - The application validates the input and displays a loading spinner.
   - It calls the `mockProcessText()` function to simulate text processing.

3. **Displaying Results**:
   - Upon successful processing, the processed text is displayed in a table with a copy button.
   - If an error occurs, an error message is shown to the user.

4. **User Actions**:
   - Users can clear the input and results using the "Clear" button.
   - Processed text can be copied to the clipboard for further use.

This JavaScript-driven flow ensures a responsive and interactive user experience, handling all aspects of text input, processing, and user feedback seamlessly.